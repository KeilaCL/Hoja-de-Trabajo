namespace chessAPI.models.player;

public sealed class clsNewPlayer
{
    public clsNewPlayer()
    {
        email = "";
    }

    public string email { get; set; }
}