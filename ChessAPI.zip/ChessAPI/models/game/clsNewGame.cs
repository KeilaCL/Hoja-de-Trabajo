namespace chessAPI.models.game;

public sealed class clsNewGame
{
    public int whites {get;set;}
    public int blacks {get;set;}
    public bool turn {get;set;}
}