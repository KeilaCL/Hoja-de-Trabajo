using chessAPI.dataAccess.interfaces;

namespace chessAPI.dataAccess.queries;

public interface IQGame : ISQLData {}
public interface IQPlayer : ISQLData {}

